"""P6: read toto-2==2.0.0 (wheel from PyPI, not imported: it needs torch) and evaluate its block
arithmetic for the notebook's default horizon, to test cell 22's suggested experiment
'set DECODE_BLOCK_SIZE = None ... and compare the quantiles'."""
import json, math, re, sys, zipfile, hashlib
whl, OUT = sys.argv[1], sys.argv[2]
src = zipfile.ZipFile(whl).read('toto2/model.py').decode()
lines = src.splitlines()
keep = [f'{i+1}: {l.strip()}' for i, l in enumerate(lines) if re.search(r'decode_block_size = kwargs|block_size_patches = |num_patches = math.ceil|use_cache = block_size_patches', l)]
patch_size = 32  # Toto 2.0 patch size, printed by the notebook as patch_size
def blocks(horizon, dbs):
    num_patches = math.ceil(horizon / patch_size)
    dbs = dbs or 0
    bsp = min(dbs // patch_size, num_patches) if dbs > 0 else num_patches
    return {'num_patches': num_patches, 'block_size_patches': bsp, 'use_kv_cache_loop': bsp < num_patches}
out = {'wheel_sha256': hashlib.sha256(open(whl, 'rb').read()).hexdigest(), 'upstream_lines': keep,
       'horizon_48': {'768': blocks(48, 768), 'None': blocks(48, None)},
       'horizon_1024': {'768': blocks(1024, 768), 'None': blocks(1024, None)}}
out['identical_path_at_default_horizon'] = out['horizon_48']['768'] == out['horizon_48']['None']
print(json.dumps(out, indent=1)); json.dump(out, open(OUT, 'w'), indent=1)
