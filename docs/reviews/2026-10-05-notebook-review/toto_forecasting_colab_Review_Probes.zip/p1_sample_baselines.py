"""P1: rebuild the default synthetic sample exactly as cell 13 does, recompute the
last-value baseline the notebook reports, and add context baselines (noise floor,
seasonal-naive, drift, harmonic least squares) computed from the context only."""
import hashlib, json, sys
import numpy as np
sys.path.insert(0, sys.argv[1] + '/src')
import types, importlib.util
pkg = types.ModuleType('toto_forecasting_pipeline'); pkg.__path__ = [sys.argv[1] + '/src/toto_forecasting_pipeline']
sys.modules['toto_forecasting_pipeline'] = pkg
from toto_forecasting_pipeline.evaluation import mae, rmse, last_value_baseline, interval_coverage
from toto_forecasting_pipeline.validation import validate_target, MIN_CONTEXT
HORIZON = 48
rng = np.random.default_rng(11)
t = np.arange(320)
first = 0.01 * t + np.sin(t / 9) + rng.normal(0, 0.04, len(t))
second = 0.5 * first + np.cos(t / 13) + rng.normal(0, 0.04, len(t))
series = validate_target(np.vstack([first, second]))
sha = hashlib.sha256(np.ascontiguousarray(series, dtype=np.float32).tobytes()).hexdigest()
context, truth = series[:, :-HORIZON], series[:, -HORIZON:]
out = {'shape': list(series.shape), 'float32_sha256': sha, 'context_length': int(context.shape[1])}
b = last_value_baseline(context, HORIZON)
out['last_value_baseline'] = {'mae': round(mae(truth, b), 6), 'rmse': round(rmse(truth, b), 6)}
out['recorded_previous_notebook'] = {'model_mae': 0.073249, 'model_rmse': 0.088706, 'baseline_mae': 1.108021, 'baseline_rmse': 1.310835, 'coverage_q10_q90': 0.822917}
# noise floor: the noiseless signal vs truth (truth minus the deterministic component)
tt = np.arange(320)
clean1 = 0.01 * tt + np.sin(tt / 9)
# second variate = 0.5*first(noisy) + cos + noise2, so its unpredictable part is 0.5*e1 + e2
clean2 = 0.5 * clean1 + np.cos(tt / 13)
oracle = np.vstack([clean1, clean2])[:, -HORIZON:]
out['oracle_noiseless_signal'] = {'mae': round(mae(truth, oracle.astype(np.float32)), 6), 'rmse': round(rmse(truth, oracle.astype(np.float32)), 6),
    'note': 'error of the exact generating function without noise: the irreducible floor for any forecaster'}
# drift (straight line from first to last context point)
n = context.shape[1]
slope = (context[:, -1] - context[:, 0]) / (n - 1)
drift = context[:, -1:] + slope[:, None] * np.arange(1, HORIZON + 1)[None, :]
out['drift_baseline'] = {'mae': round(mae(truth, drift), 6), 'rmse': round(rmse(truth, drift), 6)}
# seasonal naive with the nearest integer period of sin(t/9) (2*pi*9 = 56.5 -> 57)
for p in (57,):
    sn = np.stack([np.resize(row[-p:], HORIZON) for row in context])
    out[f'seasonal_naive_p{p}'] = {'mae': round(mae(truth, sn), 6), 'rmse': round(rmse(truth, sn), 6)}
# harmonic least squares on the context with the two frequencies used by the generator (an informed baseline)
tc = np.arange(n); tf = np.arange(n, n + HORIZON)
def design(x):
    return np.column_stack([np.ones_like(x, dtype=float), x, np.sin(x / 9), np.cos(x / 9), np.sin(x / 13), np.cos(x / 13)])
coef = np.linalg.lstsq(design(tc), context.T.astype(float), rcond=None)[0]
hl = (design(tf) @ coef).T
out['harmonic_lstsq_known_freq'] = {'mae': round(mae(truth, hl), 6), 'rmse': round(rmse(truth, hl), 6),
    'note': 'uses the generator frequencies (1/9, 1/13), so it is an informed upper reference, not a naive baseline'}
print(json.dumps(out, indent=1))
json.dump(out, open(sys.argv[2], 'w'), indent=1)
