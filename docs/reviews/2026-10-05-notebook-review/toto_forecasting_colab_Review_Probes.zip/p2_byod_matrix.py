"""P2: exec the notebook's own BYOD branch (cell 13) and validation cell (cell 15) on a matrix of
CSV inputs, with a stand-in for google.colab.files.upload. Then exec the export cell (21) with a
stand-in forecast result to show which identifiers the forecast CSV keeps."""
import json, os, sys, types, tempfile, traceback
import numpy as np
REPO, NB, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
pkg = types.ModuleType('toto_forecasting_pipeline'); pkg.__path__ = [REPO + '/src/toto_forecasting_pipeline']
sys.modules['toto_forecasting_pipeline'] = pkg
import toto_forecasting_pipeline.pipeline as P
from toto_forecasting_pipeline.evaluation import mae, rmse, last_value_baseline
from toto_forecasting_pipeline.validation import validate_target, MIN_CONTEXT, MAX_CONTEXT, MAX_HORIZON
cells = json.load(open(NB))['cells']
src = lambda i: ''.join(cells[i]['source'])
c13 = src(13).replace('USE_BYOD = False', 'USE_BYOD = True')
c15, c21 = src(15), src(21)
assert 'files.upload()' in c13 and 'validate_inputs(context' in c15

def make(name, text):
    return {name: text.encode('utf-8') if isinstance(text, str) else text}
def series_csv(n=100, cols=('a',), freq='h', bad=None):
    import pandas as pd
    ts = pd.date_range('2026-01-01', periods=n, freq=freq)
    lines = ['timestamp,' + ','.join(cols)]
    for i, t in enumerate(ts):
        vals = [f'{np.sin(i / 7) + j:.4f}' for j in range(len(cols))]
        lines.append(f'{t.isoformat()},' + ','.join(vals))
    if bad: lines = bad(lines)
    return '\n'.join(lines) + '\n'
cases = {
  'good_1var_100rows': make('g.csv', series_csv()),
  'good_3var_200rows': make('g3.csv', series_csv(200, ('a', 'b', 'c'))),
  'min_80rows': make('m.csv', series_csv(80)),
  'too_short_79rows': make('s.csv', series_csv(79)),
  'duplicate_header': make('d.csv', series_csv(100, ('a', 'a'))),
  'no_timestamp_column': make('n.csv', series_csv().replace('timestamp', 'time')),
  'only_timestamp': make('o.csv', 'timestamp\n2026-01-01\n2026-01-02\n'),
  'nan_value': make('nan.csv', series_csv(bad=lambda L: L[:5] + [L[5].rsplit(',', 1)[0] + ','] + L[6:])),
  'text_value': make('txt.csv', series_csv(bad=lambda L: L[:5] + [L[5].rsplit(',', 1)[0] + ',n/a-sensor'] + L[6:])),
  'irregular_spacing': make('irr.csv', series_csv(bad=lambda L: L[:10] + L[11:])),
  'unparseable_timestamp': make('ts.csv', series_csv(bad=lambda L: L[:3] + ['yesterday,' + L[3].split(',', 1)[1]] + L[4:])),
  'descending_timestamps': make('desc.csv', series_csv(bad=lambda L: [L[0]] + L[1:][::-1])),
  'not_utf8': make('l1.csv', series_csv().encode('utf-16')),
  'too_long_16500rows': make('long.csv', series_csv(16500, freq='min')),
  'cancelled_dialog': {},
  'two_files': {**make('a.csv', series_csv()), **make('b.csv', 'garbage')},
}
results = {}
work = tempfile.mkdtemp(); os.chdir(work)
for name, uploaded in cases.items():
    for f, b in uploaded.items():
        open(f, 'wb').write(b)
    colab = types.ModuleType('google.colab'); colab.files = types.SimpleNamespace(upload=lambda u=uploaded: dict(u))
    sys.modules['google'] = types.ModuleType('google'); sys.modules['google.colab'] = colab
    g = {'np': np, 'validate_target': validate_target, 'MIN_CONTEXT': MIN_CONTEXT, 'MAX_CONTEXT': MAX_CONTEXT,
         'MAX_HORIZON': MAX_HORIZON, 'validate_inputs': P.validate_inputs, 'last_value_baseline': last_value_baseline,
         'mae': mae, 'rmse': rmse}
    stage = 'cell13'
    try:
        import io, contextlib
        with contextlib.redirect_stdout(io.StringIO()):
            exec(c13, g); stage = 'cell15'
            exec(c15, g)
        results[name] = {'outcome': 'accepted', 'shape': list(g['series'].shape), 'files_in_upload': len(uploaded),
                         'used_file': g['sample_name'], 'context': int(g['context'].shape[1])}
    except BaseException as exc:
        results[name] = {'outcome': 'refused', 'stage': stage, 'error': f'{type(exc).__name__}: {exc}'[:300]}
    for f in uploaded:
        os.remove(f)
# export cell with a stand-in result on an accepted BYOD input
uploaded = make('g.csv', series_csv(120)); open('g.csv', 'wb').write(uploaded['g.csv'])
colab = types.ModuleType('google.colab'); colab.files = types.SimpleNamespace(upload=lambda: dict(uploaded)); sys.modules['google.colab'] = colab
import io, contextlib, platform, pandas
g = {'np': np, 'validate_target': validate_target, 'MIN_CONTEXT': MIN_CONTEXT, 'MAX_CONTEXT': MAX_CONTEXT, 'MAX_HORIZON': MAX_HORIZON, 'validate_inputs': P.validate_inputs,
     'last_value_baseline': last_value_baseline, 'mae': mae, 'rmse': rmse}
with contextlib.redirect_stdout(io.StringIO()):
    exec(c13, g); exec(c15, g)
H = g['HORIZON']; ctx = g['context']
q = np.repeat(np.repeat(ctx[:, -1:], H, axis=1)[:, None, :], 9, axis=1)
g['result'] = {'median': q[:, 4, :], 'quantiles': q, 'quantile_levels': P.QUANTILES, 'point_forecast': P.POINT_FORECAST, 'horizon': H,
               'context_length': ctx.shape[1], 'context_padding': 0, 'patch_size': 32, 'decode_block_size': 768, 'n_variates': ctx.shape[0]}
g['prediction'] = g['result']['median']; g['report'] = {}; g['NOTEBOOK_SOURCE'] = {'repository_revision': 'x'}
g.update(MODEL_ID=P.MODEL_ID, MODEL_REVISION=P.MODEL_REVISION, MODEL_LICENSE=P.MODEL_LICENSE, platform=platform, numpy=np, pandas=pandas,
         torch=types.SimpleNamespace(__version__='stand-in'), pipe=types.SimpleNamespace(device='stand-in'))
with contextlib.redirect_stdout(io.StringIO()):
    exec(c21, g)
import pandas as pd
df = pd.read_csv('outputs/toto_forecasting_forecast.csv')
res = json.load(open('outputs/toto_forecasting_result.json'))
results['export_after_byod'] = {'csv_columns': list(df.columns), 'first_row': df.iloc[0].to_dict(),
    'timestamp_anywhere_in_result_json': 'timestamp' in json.dumps(res), 'byod_upload_timestamps_last_context': str(pd.read_csv('g.csv')['timestamp'].iloc[-49])}
print(json.dumps(results, indent=1, default=str))
json.dump(results, open(OUT, 'w'), indent=1, default=str)
