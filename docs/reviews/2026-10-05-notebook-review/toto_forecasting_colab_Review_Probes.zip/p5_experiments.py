"""P5: check the 'Next experiments' controls in cell 22 against the code: which values are form
fields, whether DECODE_BLOCK_SIZE=None passes notebook-local validation, and whether any control
moves the holdout or shortens the context without editing code."""
import json, re, sys, types
import numpy as np
REPO, NB, OUT = sys.argv[1:4]
pkg = types.ModuleType('toto_forecasting_pipeline'); pkg.__path__ = [REPO + '/src/toto_forecasting_pipeline']
sys.modules['toto_forecasting_pipeline'] = pkg
import toto_forecasting_pipeline.pipeline as P
cells = json.load(open(NB))['cells']
code = {i: ''.join(c['source']) for i, c in enumerate(cells) if c['cell_type'] == 'code'}
out = {'form_fields': {i: re.findall(r"^(\w+)\s*=.*#\s*@param", s, re.M) for i, s in code.items() if '@param' in s},
       'plain_assignments_cell13': re.findall(r"^(HORIZON|DECODE_BLOCK_SIZE)\s*=\s*(.+)$", code[13], re.M),
       'holdout_expression_cell15': re.findall(r"^(context|truth) = (.+)$", code[15], re.M)}
ctx = np.ones((2, 272), dtype=np.float32)
out['validate_inputs_decode_None'] = P.validate_inputs(ctx, horizon=48, decode_block_size=None)['decode_block_size']
out['offset_or_context_length_control_present'] = bool(re.search(r"OFFSET|CONTEXT_LENGTH|HOLDOUT_START|ROLL", ''.join(code.values())))
out['export_paths_fixed'] = sorted(set(re.findall(r"outputs/[\w.]+", ''.join(code.values()))))
print(json.dumps(out, indent=1)); json.dump(out, open(OUT, 'w'), indent=1)
